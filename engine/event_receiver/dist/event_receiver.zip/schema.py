from collections import namedtuple

Field = namedtuple("Field", ["name_in", "name_out", "type", "glue_type"])

TIMESTAMP_FIELDS = ["received_datetime"]

# _cvar custom variables
# _rcn Campaign name
# _rck Campaign Keyword
#  lang: Accept-Language HTTP
#  uid user_id (str)
# cid  visitor ID (str)
# dimension[0-999] custom dimension

# events from clients
INCOMING = [
    # see https://developer.matomo.org/api-reference/tracking-api for details
    Field("idsite", "site_id", int, "int"),
    Field("r", "random_part", int, "int"),
    Field("_idts", "visitor_id_created_ts", int, "int"),
    Field("_idvc", "visitor_visit_count", int, "int"),
    Field("_refts", "referral_ts", int, "int"),
    Field("urlref", "referral_url", str, "string"),
    Field("_viewts", "visitor_last_visit_ts", int, "int"),
    Field("res", "display_resolutions", str, "string"),
    Field("gt_ms", "performance_generation_time_ms", int, "int"),
    Field("pv_id", "page_view_id", str, "string"),
    Field("url", "page_view_url", str, "string"),
    Field("action_name", "action_name", str, "string"),
    Field("ag", "supports_silverlight", bool, "boolean"),
    Field("cookie", "supports_cookie", bool, "boolean"),
    Field("dir", "supports_director", bool, "boolean"),
    Field("fla", "supports_flash", bool, "boolean"),
    Field("gears", "supports_gears", bool, "boolean"),
    Field("java", "supports_java", bool, "boolean"),
    Field("pdf", "supports_pdf", bool, "boolean"),
    Field("qt", "supports_quicktime", bool, "boolean"),
    Field("wma", "supports_mplayer2", bool, "boolean"),
    Field("realp", "supports_realaudio", bool, "boolean"),
    Field("send_image", "send_image", bool, "boolean"),
    Field("e_c", "event_category", str, "string"),
    Field("e_a", "event_action", str, "string"),
    Field("e_n", "event_value_name", str, "string"),
    Field("e_v", "event_value_numeric", float, "double"),
]

# added while lambda-processing the event
PROCESSING = [
    Field("received_datetime", "received_datetime", str, "string"),
]

GEO_INFO = [
    {
        "geo_info": [
            Field("ip", "ip", str, "string"),
            Field("hostname", "hostname", str, "string"),
            Field("city", "city", str, "string"),
            Field("region", "region", str, "string"),
            Field("country", "country", str, "string"),
            {
                "loc": [
                    Field("longitude", "longitude", float, "double"),
                    Field("latitude", "latitude", float, "double"),
                ]
            }
        ]
    }
]

# final schema for enriched events
ENRICHED = INCOMING + PROCESSING + GEO_INFO

